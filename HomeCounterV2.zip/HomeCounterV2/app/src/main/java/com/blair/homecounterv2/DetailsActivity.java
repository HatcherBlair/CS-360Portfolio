package com.blair.homecounterv2;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.navigation.NavController;
import androidx.navigation.fragment.NavHostFragment;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.bottomnavigation.BottomNavigationView;

public class DetailsActivity extends AppCompatActivity {

    // Integer for the ID of passed item
    int id;

    // TextViews
    TextView itemName;
    TextView itemCurrentName;
    TextView itemCurrentQuantity;
    TextView itemCurrentUnits;
    TextView itemCurrentCategory;

    // EditTexts
    EditText itemNewName;
    EditText itemNewQuantity;

    // Spinners
    Spinner itemNewUnits;
    Spinner itemNewCategory;

    // Buttons
    Button updateButton;
    Button deleteButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_details);

        // Linking the TextViews
        itemName = findViewById(R.id.item_name);
        itemCurrentName = findViewById(R.id.item_current_name);
        itemCurrentCategory = findViewById(R.id.item_current_category);
        itemCurrentUnits = findViewById(R.id.item_current_units);
        itemCurrentQuantity = findViewById(R.id.item_current_quantity);

        // Linking the EditTexts
        itemNewName = findViewById(R.id.item_new_name);
        itemNewQuantity = findViewById(R.id.item_new_quantity);

        // Linking the Spinners
        itemNewUnits = findViewById(R.id.spin_units);
        itemNewCategory = findViewById(R.id.spin_category);

        // Linking the Buttons
        updateButton = findViewById(R.id.update_btn);
        deleteButton = findViewById(R.id.delete_btn);

        // Adding strings to category spinner
        ArrayAdapter<CharSequence> categoryAdapter = ArrayAdapter.createFromResource(this,
                R.array.category_array,
                android.R.layout.simple_spinner_item);

        categoryAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        itemNewCategory.setAdapter(categoryAdapter);

        // Adding strings to units spinner
        ArrayAdapter<CharSequence> unitsAdapter = ArrayAdapter.createFromResource(this,
                R.array.units_array,
                android.R.layout.simple_spinner_item);

        unitsAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        itemNewUnits.setAdapter(unitsAdapter);

        Intent intent = this.getIntent();

        // Getting the extra intent data to display
        if (intent != null) {

            id = Integer.parseInt(intent.getStringExtra("ID"));

            itemName.setText(intent.getStringExtra("Name"));
            itemCurrentName.setText(intent.getStringExtra("Name"));
            itemCurrentQuantity.setText(intent.getStringExtra("Quantity"));
            itemCurrentUnits.setText(intent.getStringExtra("Units"));
            itemCurrentCategory.setText(intent.getStringExtra("Category"));
        }

        updateButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                HomeCounterDatabase itemEntry;
                HomeCounterDatabaseHelper homeCounterDatabaseHelper = new HomeCounterDatabaseHelper(DetailsActivity.this);

                try {
                    String itemUpdatedName = itemNewName.getText().toString();
                    String itemUpdatedCategory = itemNewCategory.getSelectedItem().toString();
                    Double itemUpdatedQuantity = Double.parseDouble(itemNewQuantity.getText().toString());
                    String itemUpdatedUnits = itemNewUnits.getSelectedItem().toString();
                    boolean success = homeCounterDatabaseHelper.updateOne(id, itemUpdatedName, itemUpdatedCategory, itemUpdatedQuantity, itemUpdatedUnits);
                }
                catch (Exception e) {
                    itemEntry = new HomeCounterDatabase(-1, "Error",
                            "Error", -1.0, "Error");
                }
                finish();
            }
        });

        deleteButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                HomeCounterDatabase itemEntry;

                itemEntry = new HomeCounterDatabase(id,
                        intent.getStringExtra("Name"),
                        intent.getStringExtra("Category"),
                        Double.parseDouble(intent.getStringExtra("Quantity")),
                        intent.getStringExtra("Units"));

                HomeCounterDatabaseHelper homeCounterDatabaseHelper = new HomeCounterDatabaseHelper(DetailsActivity.this);
                boolean success = homeCounterDatabaseHelper.deleteOne(itemEntry);

                finish();
            }
        });
    }

}