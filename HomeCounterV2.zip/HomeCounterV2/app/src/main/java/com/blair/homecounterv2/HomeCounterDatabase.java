package com.blair.homecounterv2;


public class HomeCounterDatabase {

    private int id;
    private String name;
    private String itemCategory;
    private double quantity;
    private String units;
    private String username;
    private String password;

    // Constructors

    public HomeCounterDatabase(int id, String name, String itemCategory, double quantity, String units) {
        this.id = id;
        this.name = name;
        this.itemCategory = itemCategory;
        this.quantity = quantity;
        this.units = units;
    }

    public HomeCounterDatabase(String username, String password) {
        this.username = username;
        this.password = password;
    }

    public HomeCounterDatabase() {
    }

    // Getters

    public String getUsername() {
        return username;
    }

    public String getPassword() {
        return password;
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getItemCategory() {
        return itemCategory;
    }

    public double getQuantity() {
        return quantity;
    }

    public String getUnits() {
        return units;
    }

    // Setters

    public void setQuantity(double quantity) {
        this.quantity = quantity;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setItemCategory(String itemCategory) {
        this.itemCategory = itemCategory;
    }

    public void setUnits(String units) {
        this.units = units;
    }

    // toString
    @Override
    public String toString() {
        return "HomeCounterDatabase{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", itemCategory=" + itemCategory +
                ", quantity=" + quantity +
                ", units=" + units +
                '}';
    }


}