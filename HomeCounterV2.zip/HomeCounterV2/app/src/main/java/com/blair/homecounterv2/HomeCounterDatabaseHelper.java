package com.blair.homecounterv2;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;
import androidx.constraintlayout.widget.ConstraintLayout;

import java.util.ArrayList;
import java.util.List;

public class HomeCounterDatabaseHelper extends SQLiteOpenHelper {


    public static final String HOME_COUNTER_TABLE = "HOME_COUNTER_TABLE";
    public static final String USER_INFORMATION = "USER_LOGIN_INFORMATION";
    public static final String COLUMN_ITEM_NAME = "ITEM_NAME";
    public static final String COLUMN_ITEM_QUANTITY = "ITEM_QUANTITY";
    public static final String COLUMN_ITEM_UNITS = "ITEM_UNITS";
    public static final String COLUMN_ITEM_ID = "ITEM_ID";
    public static final String COLUMN_ITEM_CATEGORY = "ITEM_CATEGORY";
    public static final String COLUMN_USERNAME = "USER_NAME";
    public static final String COLUMN_PASSWORD = "USER_PASSWORD";

    String createTableStatement = "CREATE TABLE " + HOME_COUNTER_TABLE +
            " (" + COLUMN_ITEM_ID + " INTEGER PRIMARY KEY AUTOINCREMENT," +
            COLUMN_ITEM_NAME + " TEXT, " +
            COLUMN_ITEM_QUANTITY + " REAL, " +
            COLUMN_ITEM_UNITS + " STRING, " +
            COLUMN_ITEM_CATEGORY + " STRING)";

    String createLoginTableStatement = "CREATE TABLE " + USER_INFORMATION +
            " (" + COLUMN_USERNAME + " STRING PRIMARY KEY," +
            COLUMN_PASSWORD + " STRING)";

    public HomeCounterDatabaseHelper(@Nullable Context context) {
        super(context, "HomeCounter.db", null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {


        db.execSQL(createLoginTableStatement);
        db.execSQL(createTableStatement);
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS '" + HOME_COUNTER_TABLE + "'");
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS '" + USER_INFORMATION + "'");
        onCreate(sqLiteDatabase);
    }

    // Add a user to the table
    public void addUser(String username, String password) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();

        cv.put(COLUMN_USERNAME, username);
        cv.put(COLUMN_PASSWORD, password);
        db.insert(USER_INFORMATION, null, cv);
    }

    public boolean loginUser(String username, String password) {

        String queryString = "SELECT * FROM " + USER_INFORMATION + " WHERE " + COLUMN_USERNAME +
                " = ? AND " + COLUMN_PASSWORD + " = ?";
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery(queryString, new String[]{username, password});
        if(cursor.moveToFirst()) {
            return true;
        } else {
            return false;
        }
    }

    // Adds an entry into the database
    public boolean addOne(HomeCounterDatabase itemEntry) {

        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();

        cv.put(COLUMN_ITEM_NAME, itemEntry.getName());
        cv.put(COLUMN_ITEM_QUANTITY, itemEntry.getQuantity());
        cv.put(COLUMN_ITEM_CATEGORY, itemEntry.getItemCategory());
        cv.put(COLUMN_ITEM_UNITS, itemEntry.getUnits());

        long insert = db.insert(HOME_COUNTER_TABLE, null, cv);
        if(insert == -1) {
            db.close();
            return false;
        } else {
            return true;
        }
    }

    // Removes an entry from the database
    public boolean deleteOne(HomeCounterDatabase itemEntry) {
        SQLiteDatabase db = this.getWritableDatabase();
        String queryString = "DELETE FROM " + HOME_COUNTER_TABLE + " WHERE " + COLUMN_ITEM_ID + " = "
                + itemEntry.getId();

        Cursor cursor = db.rawQuery(queryString, null);

        if(cursor.moveToFirst()) {
            cursor.close();
            db.close();
            return true;
        } else {
            cursor.close();
            db.close();
            return false;
        }
    }

    // Updates an entry with specified id
    public boolean updateOne(int id, String name, String category, double quantity, String units) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();

        cv.put(COLUMN_ITEM_NAME, name);
        cv.put(COLUMN_ITEM_UNITS, units);
        cv.put(COLUMN_ITEM_CATEGORY, category);
        cv.put(COLUMN_ITEM_QUANTITY, quantity);
        cv.put(COLUMN_ITEM_ID, id);

        db.update(HOME_COUNTER_TABLE, cv, "id=?", new String[]{name});
        db.close();

        return true;
    }

    // Returns all entries in the database
    public List<HomeCounterDatabase> getEveryone() {
        List<HomeCounterDatabase> returnList = new ArrayList<>();

        // Get data from DB
        String queryString = "SELECT * FROM " + HOME_COUNTER_TABLE;
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(queryString, null);

        if (cursor.moveToFirst()) {
            // Loop through results from query
            do {
                int id = cursor.getInt(0);
                String itemName = cursor.getString(1);
                Double itemQuantity = cursor.getDouble(2);
                String itemUnits = cursor.getString(3);
                String itemCategory = cursor.getString(4);

                HomeCounterDatabase newItem = new HomeCounterDatabase(id, itemName, itemCategory, itemQuantity, itemUnits);
                returnList.add(newItem);

            } while (cursor.moveToNext());
        }

        cursor.close();
        db.close();
        return returnList;
    }
}
