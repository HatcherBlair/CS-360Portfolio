package com.blair.homecounterv2;

import android.content.Intent;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

import java.util.List;

public class DatabaseFragment extends Fragment {

    // Database Helper
    HomeCounterDatabaseHelper dbHelper;
    // Array Adapter
    ArrayAdapter itemArrayAdapter;
    // Spinners
    Spinner categorySpinner;
    Spinner unitsSpinner;

    // Edit texts
    EditText nameEditText;
    EditText quantityEditText;

    // Buttons
    Button addItemButton;
    Button updateDBButton;

    // TextViews
    ListView allItemsListView;

    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        // Inflating the view
        View rootView = inflater.inflate(R.layout.fragment_database, container, false);
        dbHelper = new HomeCounterDatabaseHelper(getActivity());

        return rootView;
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {

        // Adding strings to category spinner
        categorySpinner = (Spinner) getView().findViewById(R.id.spin_category);

        ArrayAdapter<CharSequence> categoryAdapter = ArrayAdapter.createFromResource(this.getContext(),
                R.array.category_array,
                android.R.layout.simple_spinner_item);

        categoryAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        categorySpinner.setAdapter(categoryAdapter);

        // Adding strings to units spinner
        unitsSpinner = (Spinner) getView().findViewById(R.id.spin_units);

        ArrayAdapter<CharSequence> unitsAdapter = ArrayAdapter.createFromResource(this.getContext(),
                R.array.units_array,
                android.R.layout.simple_spinner_item);

        unitsAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        unitsSpinner.setAdapter(unitsAdapter);

        // Creating ListView
        allItemsListView = (ListView) getView().findViewById(R.id.lv_all_items);

        // Creating Edit Texts
        nameEditText = (EditText) getView().findViewById(R.id.et_name);
        quantityEditText = (EditText) getView().findViewById(R.id.et_quantity);

        // Creating Buttons
        addItemButton = (Button) getView().findViewById(R.id.butt_add_item);
        updateDBButton = (Button) getView().findViewById(R.id.butt_update_db);

        addItemButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                HomeCounterDatabase itemEntry;

                try {
                    itemEntry = new HomeCounterDatabase(-1,
                            nameEditText.getText().toString(),
                            categorySpinner.getSelectedItem().toString(),
                            Double.parseDouble(quantityEditText.getText().toString()),
                            unitsSpinner.getSelectedItem().toString());
                }
                catch (Exception e) {
                    Toast.makeText(getActivity(), "Error adding item", Toast.LENGTH_SHORT).show();
                    itemEntry = new HomeCounterDatabase(-1, "Error",
                            "Error", -1.0, "Error");
                }

                HomeCounterDatabaseHelper homeCounterDatabaseHelper = new HomeCounterDatabaseHelper(getActivity());
                boolean success = homeCounterDatabaseHelper.addOne(itemEntry);

                // Update database after every entry
                showListView();
            }
        });

        updateDBButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showListView();
            }
        });

        allItemsListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                HomeCounterDatabase clickedItem = (HomeCounterDatabase) adapterView.getItemAtPosition(i);

                Intent intent = new Intent(getActivity(), DetailsActivity.class);
                intent.putExtra("Name", clickedItem.getName());
                intent.putExtra("Quantity", Double.toString(clickedItem.getQuantity()));
                intent.putExtra("Units", clickedItem.getUnits());
                intent.putExtra("Category", clickedItem.getItemCategory());
                intent.putExtra("ID", Integer.toString(clickedItem.getId()));
                startActivity(intent);
            }
        });


    }

    private void showListView() {
        dbHelper = new HomeCounterDatabaseHelper(getActivity());
        itemArrayAdapter = new ArrayAdapter<HomeCounterDatabase>(getActivity(),
                android.R.layout.simple_list_item_1, dbHelper.getEveryone());
        allItemsListView.setAdapter(itemArrayAdapter);
    }
}