package com.blair.homecounterv2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private EditText mUsernameText;
    private EditText mPasswordText;
    private Button mLoginButton;
    private Button mSignupButton;
    String username;
    String password;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mUsernameText = findViewById(R.id.username_field);
        mPasswordText = findViewById(R.id.password_field);
        mLoginButton = findViewById(R.id.login_button);
        mSignupButton = findViewById(R.id.create_account_button);

        mLoginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                     username = mUsernameText.getText().toString();
                     password = mPasswordText.getText().toString();
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this, "Enter a username and password", Toast.LENGTH_SHORT);
                }

                HomeCounterDatabaseHelper helper = new HomeCounterDatabaseHelper(MainActivity.this);

                if (helper.loginUser(username, password)) {
                    Toast.makeText(MainActivity.this, "Login Successful", Toast.LENGTH_SHORT);
                    Intent intent = new Intent(MainActivity.this, HomeActivity.class);
                    startActivity(intent);
                } else {
                    Toast.makeText(MainActivity.this, "Invalid login information", Toast.LENGTH_SHORT);
                }
            }
        });

        mSignupButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    username = mUsernameText.getText().toString();
                    password = mPasswordText.getText().toString();
                    HomeCounterDatabaseHelper helper = new HomeCounterDatabaseHelper(MainActivity.this);
                    if (helper.loginUser(username, password)) {
                        Toast.makeText(MainActivity.this, "User already exists", Toast.LENGTH_SHORT);
                    } else {
                        helper.addUser(username, password);
                        Intent intent = new Intent(MainActivity.this, HomeActivity.class);
                        startActivity(intent);

                        Toast.makeText(MainActivity.this, "Account Created", Toast.LENGTH_SHORT);
                    }
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this, "Enter a username and password", Toast.LENGTH_SHORT);
                }
            }
        });
    }
}